import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-various',
  templateUrl: './various.component.html',
  styleUrls: ['./various.component.css']
})
export class VARIOUSComponent implements OnInit {

  constructor() { }

  ngOnInit(){
    let dataMap = [
      {name: '(choisissez)'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
      {name: 'Facebook'},
    ]
  }

}
