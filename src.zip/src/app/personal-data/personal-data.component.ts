import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-data',
  templateUrl: './personal-data.component.html',
  styleUrls: ['./personal-data.component.css']
})
export class PERSONALDATAComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
