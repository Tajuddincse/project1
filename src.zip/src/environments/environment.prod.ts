export const environment = {
  firebase: {
    projectId: 'chatbizz-7ec13',
    appId: '1:644352173730:web:2d4d6b584638684da259fb',
    databaseURL: 'https://chatbizz-7ec13-default-rtdb.firebaseio.com',
    storageBucket: 'chatbizz-7ec13.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyBqvfaVJ34GeJy9QkGwKU21h3EZqXAvI8w',
    authDomain: 'chatbizz-7ec13.firebaseapp.com',
    messagingSenderId: '644352173730',
    measurementId: 'G-ENHRS1HP2L',
  },
  production: true
};
